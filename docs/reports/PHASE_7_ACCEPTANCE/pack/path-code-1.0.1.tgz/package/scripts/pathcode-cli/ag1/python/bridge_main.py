#!/usr/bin/env python3
"""PATH AG1 — Antigravity JSONL bridge (stdout = protocol only)."""

from __future__ import annotations

import asyncio
import contextlib
import json
import os
import re
import sys
import traceback
from pathlib import Path
from typing import Any

# stderr-only diagnostics; never write human logs to stdout.
def _diag(msg: str) -> None:
    sys.stderr.write(msg.rstrip() + "\n")
    sys.stderr.flush()


def _emit(obj: dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(obj, separators=(",", ":"), ensure_ascii=True) + "\n")
    sys.stdout.flush()


def _looks_like_mcp_tool(name: str, args: dict[str, Any] | None = None) -> bool:
    n = (name or "").lower()
    args = args or {}
    if args.get("server_name") or args.get("serverName") or args.get("mcp_server"):
        return True
    if "mcp" in n:
        return True
    # Antigravity MCP tools are often namespaced as "server/tool".
    if "/" in n and not n.startswith(("http://", "https://", "./", "../")):
        return True
    return False


def _activity_for_tool(name: str, args: dict[str, Any] | None = None) -> str:
    n = (name or "").lower()
    args = args or {}
    if _looks_like_mcp_tool(name, args):
        return "mcp"
    cmd = str(args.get("CommandLine") or args.get("command") or "").lower()
    if n in ("view_file", "list_directory", "find_file", "search_directory"):
        return "inspecting"
    if n in ("edit_file", "create_file"):
        return "editing"
    if n == "run_command":
        test_markers = (
            "test",
            "vitest",
            "pytest",
            "jest",
            "mocha",
            "cargo test",
            "cargo check",
            "go test",
            "ctest",
            "cmake --build",
            "bazel test",
            "mvn test",
            "gradle test",
        )
        if any(t in cmd for t in test_markers):
            return "testing"
        if any(t in cmd for t in ("tsc", "typecheck", "mypy", "eslint", "lint", "cargo clippy")):
            return "testing"
        if any(t in cmd for t in ("build", "compile")):
            return "testing"
        return "running_command"
    if n == "finish":
        return "complete"
    if n in ("ask_question",):
        return "understanding"
    return "inspecting"


def _normalize_mcp_servers(raw: Any) -> list[Any]:
    """Coerce start-payload mcpServers into LocalAgentConfig mcp_servers entries."""
    if not isinstance(raw, list) or not raw:
        return []
    try:
        from google.antigravity.types import McpStdioServer, McpStreamableHttpServer
    except Exception:  # noqa: BLE001
        # Fall back to plain dicts; pydantic may still coerce.
        return [item for item in raw if isinstance(item, dict)]

    servers: list[Any] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        try:
            stype = str(item.get("type") or "stdio").lower()
            name = str(item.get("name") or "mcp")
            common: dict[str, Any] = {"name": name}
            if item.get("enabled_tools") is not None:
                common["enabled_tools"] = item.get("enabled_tools")
            if item.get("disabled_tools") is not None:
                common["disabled_tools"] = item.get("disabled_tools")
            if item.get("timeout_seconds") is not None:
                common["timeout_seconds"] = item.get("timeout_seconds")
            if stype in ("http", "streamable_http", "sse"):
                url = item.get("url")
                if not url:
                    continue
                kwargs: dict[str, Any] = {**common, "url": str(url)}
                if item.get("headers") is not None:
                    kwargs["headers"] = item.get("headers")
                servers.append(McpStreamableHttpServer(**kwargs))
            else:
                command = item.get("command")
                if not command:
                    continue
                kwargs = {
                    **common,
                    "command": str(command),
                    "args": list(item.get("args") or []),
                }
                if item.get("env") is not None:
                    kwargs["env"] = item.get("env")
                servers.append(McpStdioServer(**kwargs))
        except Exception as exc:  # noqa: BLE001
            _diag(f"mcp server config skipped: {exc!r}")
    return servers


_HIGH_RISK_PATTERNS = [
    re.compile(r"\bgit\s+push\b", re.I),
    re.compile(r"\bgit\s+remote\b", re.I),
    re.compile(r"\bdeploy\b", re.I),
    re.compile(r"\bpublish\b", re.I),
    re.compile(r"\bterraform\s+apply\b", re.I),
    re.compile(r"\bgcloud\s+", re.I),
    re.compile(r"\baws\s+", re.I),
    re.compile(r"\bkubectl\s+", re.I),
    re.compile(r"\bdocker\s+(push|login)\b", re.I),
    re.compile(r"\bnpm\s+publish\b", re.I),
]


def _is_high_risk_command(command_line: str) -> bool:
    return any(p.search(command_line or "") for p in _HIGH_RISK_PATTERNS)


def _resolve_under(root: Path, candidate: str | None) -> Path | None:
    if candidate is None or str(candidate).strip() == "":
        return root.resolve()
    p = Path(candidate).expanduser()
    if not p.is_absolute():
        p = (root / p).resolve()
    else:
        p = p.resolve()
    return p


def _is_within(root: Path, path: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


class BridgeState:
    def __init__(self) -> None:
        self.cancel_requested = asyncio.Event()
        self.continue_event = asyncio.Event()
        self.continue_text: str | None = None
        self.done_event = asyncio.Event()
        self.agent = None
        self.task: asyncio.Task | None = None
        self.workspace: Path | None = None
        self.allow_shell = True
        # FIFO of pre-tool args so post-tool observe can emit real argv/paths
        # (PostToolCall only sees the result text, not the call arguments).
        self.pending_tool_calls: list[dict[str, Any]] = []


STATE = BridgeState()
MAX_CONTINUES = 3
CONTINUE_WAIT_SECONDS = 300.0


def _tool_path_from_args(args: dict[str, Any]) -> str:
    for key in (
        "Path",
        "path",
        "TargetFile",
        "AbsolutePath",
        "file_path",
        "target_file",
        "FilePath",
        "DirectoryPath",
        "directory",
        "dir",
    ):
        val = args.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()
    return ""


def _tool_query_from_args(args: dict[str, Any]) -> str:
    for key in ("Query", "query", "Pattern", "pattern", "SearchPath", "search"):
        val = args.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()
    return ""


def _tool_command_from_args(args: dict[str, Any]) -> str:
    for key in ("CommandLine", "command", "cmd"):
        val = args.get(key)
        if isinstance(val, str) and val.strip():
            return val.strip()
    return ""


async def _run_engineering_task(payload: dict[str, Any]) -> None:
    from google.antigravity import Agent, LocalAgentConfig
    from google.antigravity.hooks import PostToolCallHook, PreToolCallDecideHook, policy
    from google.antigravity.hooks.hooks import HookResult
    from google.antigravity.types import (
        AgentBehavior,
        BudgetConfig,
        BuiltinTools,
        CapabilitiesConfig,
        RunCommandConfig,
        ToolCall,
    )

    task_id = payload.get("taskId") or "unknown"
    workspace = Path(payload["workspace"]).resolve()
    default_cwd_raw = payload.get("defaultCwd") or payload.get("default_cwd")
    if isinstance(default_cwd_raw, str) and default_cwd_raw.strip():
        default_cwd = Path(default_cwd_raw).expanduser().resolve()
        if not _is_within(workspace, default_cwd):
            default_cwd = workspace
    else:
        default_cwd = workspace
    task_text = payload.get("task") or ""
    budget = payload.get("budget") or {}
    allow_shell = bool(payload.get("allowShell", True))
    STATE.workspace = workspace
    STATE.allow_shell = allow_shell

    max_model_calls = int(budget.get("maxModelCalls") or 48)
    max_tool_calls = int(budget.get("maxToolCalls") or 200)
    wall_ms = int(budget.get("wallClockMs") or 1_200_000)

    # Limited env: keep PATH/HOME/locale and auth vars the SDK needs; drop unrelated secrets.
    # AG5: never forward PATH-private Python venv markers into project commands.
    limited_env: dict[str, str] = {}
    keep_keys = (
        "PATH",
        "HOME",
        "USER",
        "LANG",
        "LC_ALL",
        "LC_CTYPE",
        "TZ",
        "TMPDIR",
        "TMP",
        "TEMP",
        "TERM",
        "SHELL",
        "GEMINI_API_KEY",
        "GOOGLE_API_KEY",
        "GOOGLE_GENAI_USE_VERTEXAI",
        "GOOGLE_GENAI_USE_ENTERPRISE",
        "GOOGLE_CLOUD_PROJECT",
        "GOOGLE_CLOUD_LOCATION",
        "GOOGLE_APPLICATION_CREDENTIALS",
        "CLOUDSDK_CORE_PROJECT",
    )
    deny_keys = {
        "VIRTUAL_ENV",
        "PYTHONHOME",
        "PYTHONPATH",
        "CONDA_PREFIX",
        "CONDA_DEFAULT_ENV",
        "CONDA_PROMPT_MODIFIER",
        "CONDA_SHLVL",
        "CONDA_PYTHON_EXE",
        "CONDA_EXE",
        "_OLD_VIRTUAL_PATH",
        "_OLD_VIRTUAL_PYTHONHOME",
        "_OLD_VIRTUAL_PS1",
    }
    for key in keep_keys:
        if key in deny_keys:
            continue
        val = os.environ.get(key)
        if isinstance(val, str) and val != "":
            limited_env[key] = val
    # Strip PATH-owned ag1-venv bin directories from PATH if present.
    path_val = limited_env.get("PATH", "")
    if path_val:
        parts = path_val.split(os.pathsep)
        cleaned = []
        for part in parts:
            norm = os.path.normpath(part)
            if norm.endswith(os.path.join("ag1-venv", "bin")) or norm.endswith(
                os.path.join("ag1-venv", "Scripts")
            ):
                continue
            if f"{os.sep}ag1-venv{os.sep}" in norm and (
                norm.endswith(f"{os.sep}bin") or norm.endswith(f"{os.sep}Scripts")
            ):
                continue
            cleaned.append(part)
        limited_env["PATH"] = os.pathsep.join(cleaned)
    # G9: merge PATH-managed tool env (bin prepend already applied by parent).
    tool_env = payload.get("toolEnv") or payload.get("tool_env")
    if isinstance(tool_env, dict):
        for key, val in tool_env.items():
            if not isinstance(key, str) or not isinstance(val, str):
                continue
            if key in deny_keys:
                continue
            # Never let project env override auth isolation via empty wipe.
            if key == "PATH" and val:
                # Parent already composed PATH with prepends; prefer toolEnv PATH.
                limited_env["PATH"] = val
            elif key != "PATH" and val != "":
                # Allow only safe non-secret tooling vars.
                if key in (
                    "MISE_DATA_DIR",
                    "MISE_CONFIG_DIR",
                    "MISE_CACHE_DIR",
                    "COPILOT_HOME",
                    "JAVA_HOME",
                    "GOROOT",
                    "GOPATH",
                    "CARGO_HOME",
                    "RUSTUP_HOME",
                    "DOTNET_ROOT",
                ):
                    limited_env[key] = val
        _diag(f"tool_env_keys={len([k for k in tool_env if isinstance(k, str)])}")
    # AG3 noninteractive engineering guards (never global CI=true).
    limited_env["GIT_TERMINAL_PROMPT"] = "0"
    limited_env["GCM_INTERACTIVE"] = "never"
    limited_env["PATHCODE_NONINTERACTIVE"] = "1"

    class CwdConfineHook(PreToolCallDecideHook):
        async def run(self, context, data: ToolCall) -> HookResult:  # type: ignore[override]
            del context
            name = data.name or ""
            args = dict(data.args or {})
            # Stash call args for PostTool observe (real command/path evidence).
            try:
                STATE.pending_tool_calls.append({"name": str(name), "args": args})
                if len(STATE.pending_tool_calls) > 64:
                    STATE.pending_tool_calls = STATE.pending_tool_calls[-64:]
            except Exception:  # noqa: BLE001
                pass
            if name == BuiltinTools.RUN_COMMAND.value or name == "run_command":
                if not STATE.allow_shell:
                    return HookResult(
                        allow=False,
                        message="Autonomous shell is unavailable: sandbox confinement not proven.",
                    )
                cmd = str(args.get("CommandLine") or args.get("command") or "")
                if _is_high_risk_command(cmd):
                    return HookResult(
                        allow=False,
                        message="High-impact external command denied for this engineering session.",
                    )
                # AG3: block known interactive-only commands before they hang PATH.
                interactive_patterns = (
                    r"\bpython3?\s+-i\b",
                    r"\bnode\s+(?:--interactive|-i)\b",
                    r"\birb\b",
                    r"\bprisma\s+studio\b",
                    r"\b(?:vim|nvim|nano|less|more)\b",
                    r"\bgit\s+add\s+-p\b",
                    r"\bgit\s+rebase\s+-i\b",
                )
                for pat in interactive_patterns:
                    if re.search(pat, cmd, re.I):
                        return HookResult(
                            allow=False,
                            message=(
                                "INTERACTIVE_COMMAND_BLOCKED: interactive command "
                                "refused for autonomous engineering. Prefer "
                                "noninteractive flags when available."
                            ),
                        )
                cwd_raw = args.get("Cwd") or args.get("cwd")
                if cwd_raw is None or str(cwd_raw).strip() == "":
                    resolved = default_cwd
                else:
                    resolved = _resolve_under(workspace, str(cwd_raw))
                if resolved is None or not _is_within(workspace, resolved):
                    return HookResult(
                        allow=False,
                        message="Command Cwd is outside the task workspace and was refused.",
                    )
                # Keep the resolved cwd (subdir-aware); do not collapse to repo root.
                return HookResult(
                    allow=True,
                    modified_args={**args, "Cwd": str(resolved)},
                )
            # File tools are workspace-scoped by harness + workspace_only policy.
            return HookResult(allow=True)

    class ObserveToolHook(PostToolCallHook):
        async def run(self, context, data) -> None:  # type: ignore[override]
            del context
            try:
                # PostToolCallHook receives ToolResult (name/result/…).
                name = getattr(data, "name", "") or ""
                result_text = str(getattr(data, "result", "") or "")
                server_name = (
                    getattr(data, "server_name", None)
                    or getattr(data, "serverName", None)
                    or ""
                )
                # Recover real argv/path from the matching PreToolCall stash.
                call_args: dict[str, Any] = {}
                try:
                    for i, pending in enumerate(STATE.pending_tool_calls):
                        if str(pending.get("name") or "") == str(name):
                            call_args = dict(pending.get("args") or {})
                            STATE.pending_tool_calls.pop(i)
                            break
                    if not call_args and STATE.pending_tool_calls:
                        # FIFO fallback when names diverge slightly.
                        call_args = dict(STATE.pending_tool_calls.pop(0).get("args") or {})
                except Exception:  # noqa: BLE001
                    call_args = {}

                cmd = _tool_command_from_args(call_args)
                path = _tool_path_from_args(call_args)
                query = _tool_query_from_args(call_args)

                observe_args: dict[str, Any] = dict(call_args)
                if cmd:
                    observe_args["CommandLine"] = cmd
                if server_name:
                    observe_args["server_name"] = str(server_name)
                activity = _activity_for_tool(str(name), observe_args)
                kind = (
                    "command"
                    if "run_command" in str(name)
                    else "file_edit"
                    if "edit" in str(name) or "create" in str(name)
                    else "inspect"
                )
                if activity == "testing":
                    kind = "test"
                if activity == "mcp":
                    kind = "mcp"
                activity_msg: dict[str, Any] = {
                    "type": "activity",
                    "taskId": task_id,
                    "activity": activity,
                    "tool": str(name),
                }
                if activity == "mcp":
                    activity_msg["detail"] = str(server_name or name)[:120]
                elif cmd:
                    activity_msg["detail"] = cmd[:160]
                elif path:
                    activity_msg["detail"] = path[:160]
                elif query:
                    activity_msg["detail"] = query[:160]
                _emit(activity_msg)

                if cmd:
                    summary = f"run_command {cmd}".strip()[:400]
                elif path:
                    summary = f"{name} {path}".strip()[:400]
                elif query:
                    summary = f"{name} {query}".strip()[:400]
                else:
                    summary = f"{name} {result_text}".strip()[:400]

                tool_msg: dict[str, Any] = {
                    "type": "tool",
                    "taskId": task_id,
                    "kind": kind,
                    "tool": str(name),
                    "summary": summary,
                }
                if cmd:
                    tool_msg["command"] = cmd[:500]
                if path:
                    tool_msg["path"] = path[:400]
                if query:
                    tool_msg["query"] = query[:200]
                if result_text.strip():
                    tool_msg["output"] = result_text.strip()[:4000]
                _emit(tool_msg)
            except Exception as exc:  # noqa: BLE001
                _diag(f"observe hook error: {exc!r}")

    enabled = [
        BuiltinTools.LIST_DIR,
        BuiltinTools.SEARCH_DIR,
        BuiltinTools.FIND_FILE,
        BuiltinTools.VIEW_FILE,
        BuiltinTools.CREATE_FILE,
        BuiltinTools.EDIT_FILE,
        BuiltinTools.FINISH,
    ]
    if allow_shell:
        enabled.append(BuiltinTools.RUN_COMMAND)

    mcp_servers = _normalize_mcp_servers(
        payload.get("mcpServers") or payload.get("mcp_servers")
    )

    policies = [
        *policy.workspace_only([str(workspace)]),
        policy.deny(BuiltinTools.SEARCH_WEB.value),
        policy.deny(BuiltinTools.READ_URL_CONTENT.value),
        policy.deny(BuiltinTools.GENERATE_IMAGE.value),
        policy.deny(BuiltinTools.ASK_QUESTION.value),
        policy.deny(BuiltinTools.START_SUBAGENT.value),
        policy.allow(BuiltinTools.LIST_DIR.value),
        policy.allow(BuiltinTools.SEARCH_DIR.value),
        policy.allow(BuiltinTools.FIND_FILE.value),
        policy.allow(BuiltinTools.VIEW_FILE.value),
        policy.allow(BuiltinTools.CREATE_FILE.value),
        policy.allow(BuiltinTools.EDIT_FILE.value),
        policy.allow(BuiltinTools.FINISH.value),
    ]
    if allow_shell:
        policies.append(policy.allow(BuiltinTools.RUN_COMMAND.value))
    else:
        policies.append(policy.deny(BuiltinTools.RUN_COMMAND.value))

    # Allow only the filtered MCP tools PATH already scoped (enabled_tools).
    # Without this, deny_all hides/denies MCP even when LocalAgentConfig lists servers.
    for mcp_cfg in mcp_servers:
        enabled_tools = getattr(mcp_cfg, "enabled_tools", None)
        try:
            if isinstance(enabled_tools, list) and enabled_tools:
                policies.extend(policy.allow(mcp_cfg, mcp_tools=enabled_tools))
            else:
                # No explicit allowlist on the config → server-wide allow for
                # this trusted/filtered server only (still deny_all for others).
                policies.extend(policy.allow(mcp_cfg))
        except Exception as exc:  # noqa: BLE001
            _diag(f"mcp policy allow failed: {exc!r}")

    # Deny-by-default for anything else.
    policies.insert(0, policy.deny_all())

    system_instructions = (
        "You are the PATH engineering engine. Complete the coding task inside the "
        "configured workspace only. Investigate, edit, run tests/typechecks/builds "
        "as needed, diagnose failures, and correct your own work. Do not push to "
        "remotes, deploy, or access secrets outside the workspace. Never run "
        "interactive prompts (editors, REPLs, git add -p). Prefer noninteractive "
        "flags such as --yes / --non-interactive when a tool requires confirmation. "
        "When finished, use the finish tool. Do not ask the operator clarifying "
        "questions."
    )
    capability_brief = payload.get("capabilityBrief") or payload.get("capability_brief")
    if isinstance(capability_brief, str) and capability_brief.strip():
        system_instructions = (
            f"{system_instructions}\n\nCapability briefing (factual):\n"
            f"{capability_brief.strip()[:4000]}"
        )

    api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    project = os.environ.get("GOOGLE_CLOUD_PROJECT") or os.environ.get(
        "CLOUDSDK_CORE_PROJECT"
    )
    location = os.environ.get("GOOGLE_CLOUD_LOCATION") or "us-central1"
    # Default to a model known to work on Agent Platform; override via AG1_MODEL.
    model_name = (
        os.environ.get("AG1_MODEL")
        or os.environ.get("GOOGLE_CLOUD_MODEL")
        or "gemini-2.5-flash"
    )
    use_vertex = os.environ.get("GOOGLE_GENAI_USE_VERTEXAI", "").lower() in (
        "true",
        "1",
    ) or os.environ.get("GOOGLE_GENAI_USE_ENTERPRISE", "").lower() in ("true", "1")
    # Prefer Vertex/ADC whenever a cloud project is configured. A present
    # GEMINI_API_KEY may be invalid for Express mode and must not win.
    if project:
        use_vertex = True

    config_kwargs: dict[str, Any] = {
        "system_instructions": system_instructions,
        "workspaces": [str(workspace)],
        "env": limited_env,
        "model": model_name,
        "capabilities": CapabilitiesConfig(
            agent_behavior=AgentBehavior.AUTONOMOUS,
            enable_subagents=False,
            enabled_tools=enabled,
            run_command_config=RunCommandConfig(
                enable_sandbox=True,
                timeout_seconds=float(budget.get("commandTimeoutSeconds") or 300),
            ),
        ),
        "policies": policies,
        "hooks": [CwdConfineHook(), ObserveToolHook()],
        "budget_config": BudgetConfig(
            max_model_calls=max_model_calls,
            max_tool_calls=max_tool_calls,
        ),
    }
    if mcp_servers:
        config_kwargs["mcp_servers"] = mcp_servers
        _diag(f"mcp_servers={len(mcp_servers)}")
    if use_vertex and project:
        config_kwargs["vertex"] = True
        config_kwargs["project"] = project
        config_kwargs["location"] = location
        _diag(f"auth_mode=vertex project={project} location={location} model={model_name}")
    elif api_key:
        config_kwargs["api_key"] = api_key
        config_kwargs["vertex"] = False
        _diag(f"auth_mode=api_key model={model_name}")
    else:
        _emit(
            {
                "type": "failed",
                "taskId": task_id,
                "code": "AG1_AUTH_FAILED",
                "message": "No Vertex project/ADC and no GEMINI_API_KEY for engineering.",
            }
        )
        return

    config = LocalAgentConfig(**config_kwargs)

    _emit({"type": "activity", "taskId": task_id, "activity": "understanding"})

    try:
        async with Agent(config) as agent:
            STATE.agent = agent
            _emit({"type": "started", "taskId": task_id, "workspace": str(workspace)})

            async def _watch_cancel() -> None:
                await STATE.cancel_requested.wait()
                try:
                    await agent.conversation.connection.cancel()
                except Exception as exc:  # noqa: BLE001
                    _diag(f"cancel via connection failed: {exc!r}")

            cancel_watcher = asyncio.create_task(_watch_cancel())
            try:
                loop = asyncio.get_running_loop()
                deadline = loop.time() + (wall_ms / 1000.0)

                async def _drain_response(response: Any) -> str:
                    async def _drain_tools() -> None:
                        try:
                            async for call in response.tool_calls:
                                name = getattr(call, "name", "") or ""
                                args = dict(getattr(call, "args", None) or {})
                                activity = _activity_for_tool(str(name), args)
                                msg: dict[str, Any] = {
                                    "type": "activity",
                                    "taskId": task_id,
                                    "activity": activity,
                                    "tool": str(name),
                                }
                                if activity == "mcp":
                                    detail = str(
                                        args.get("server_name")
                                        or args.get("serverName")
                                        or name
                                    )[:120]
                                    msg["detail"] = detail
                                else:
                                    cmd = _tool_command_from_args(args)
                                    path = _tool_path_from_args(args)
                                    query = _tool_query_from_args(args)
                                    if cmd:
                                        msg["detail"] = cmd[:160]
                                    elif path:
                                        msg["detail"] = path[:160]
                                    elif query:
                                        msg["detail"] = query[:160]
                                _emit(msg)
                        except asyncio.CancelledError:
                            raise
                        except Exception as exc:  # noqa: BLE001
                            _diag(f"tool_calls stream: {exc!r}")
                            raise

                    async def _drain_text() -> str:
                        return await response.text()

                    tools_task = asyncio.create_task(_drain_tools())
                    try:
                        # Shield the response drain so harness teardown CancelledError
                        # cannot swallow a real engine/auth failure mid-flight.
                        text = await asyncio.shield(_drain_text())
                    except Exception as exc:  # noqa: BLE001
                        tools_task.cancel()
                        with contextlib.suppress(Exception):
                            await tools_task
                        raise RuntimeError(
                            f"engineering response failed: {exc!r}"
                        ) from exc
                    with contextlib.suppress(Exception):
                        await tools_task
                    return text or ""

                async def _wait_parent_signal(timeout_s: float) -> str:
                    """Return 'continue' | 'done' | 'cancel' | 'timeout'."""
                    STATE.continue_event.clear()
                    cont_t = asyncio.create_task(STATE.continue_event.wait())
                    done_t = asyncio.create_task(STATE.done_event.wait())
                    cancel_t = asyncio.create_task(STATE.cancel_requested.wait())
                    try:
                        done_set, pending = await asyncio.wait(
                            {cont_t, done_t, cancel_t},
                            timeout=max(0.1, timeout_s),
                            return_when=asyncio.FIRST_COMPLETED,
                        )
                        for t in pending:
                            t.cancel()
                            with contextlib.suppress(asyncio.CancelledError):
                                await t
                        if STATE.cancel_requested.is_set():
                            return "cancel"
                        if STATE.done_event.is_set():
                            return "done"
                        if STATE.continue_event.is_set():
                            return "continue"
                        if not done_set:
                            return "timeout"
                        return "timeout"
                    finally:
                        for t in (cont_t, done_t, cancel_t):
                            if not t.done():
                                t.cancel()
                                with contextlib.suppress(asyncio.CancelledError):
                                    await t

                prompt = (
                    f"Engineering task:\n{task_text}\n\n"
                    f"Workspace: {workspace}\n"
                    f"Default command cwd: {default_cwd}\n"
                    "Stay inside this workspace. Carry out the engineering task as written, "
                    "including its explicit creator constraints. Do not expand the task "
                    "beyond that text. Use project-native checks when the task calls for "
                    "validation. Do not push, deploy, or leave the workspace."
                )
                remaining = max(1.0, deadline - loop.time())
                response = await asyncio.wait_for(agent.chat(prompt), timeout=remaining)
                text = await _drain_response(response)

                if STATE.cancel_requested.is_set():
                    _emit({"type": "cancelled", "taskId": task_id})
                    return

                _emit(
                    {
                        "type": "finished",
                        "taskId": task_id,
                        "summary": (text or "")[:4000],
                    }
                )

                continues = 0
                while continues < MAX_CONTINUES:
                    remaining = deadline - loop.time()
                    if remaining <= 1.0:
                        _diag("continue wait skipped: wall clock exhausted")
                        break
                    wait_s = min(CONTINUE_WAIT_SECONDS, remaining)
                    signal = await _wait_parent_signal(wait_s)
                    if signal == "cancel":
                        _emit({"type": "cancelled", "taskId": task_id})
                        return
                    if signal in ("done", "timeout"):
                        _diag(f"continue loop end: {signal}")
                        break

                    continue_text = STATE.continue_text or ""
                    STATE.continue_text = None
                    continues += 1
                    _emit(
                        {
                            "type": "activity",
                            "taskId": task_id,
                            "activity": "repairing",
                            "detail": "same-session repair",
                        }
                    )
                    remaining = max(1.0, deadline - loop.time())
                    response = await asyncio.wait_for(
                        agent.chat(continue_text), timeout=remaining
                    )
                    text = await _drain_response(response)

                    if STATE.cancel_requested.is_set():
                        _emit({"type": "cancelled", "taskId": task_id})
                        return

                    _emit(
                        {
                            "type": "finished",
                            "taskId": task_id,
                            "summary": (text or "")[:4000],
                        }
                    )
            finally:
                cancel_watcher.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await cancel_watcher
    except asyncio.TimeoutError:
        _emit(
            {
                "type": "failed",
                "taskId": task_id,
                "code": "BUDGET_WALL_CLOCK",
                "message": "Task exceeded wall-clock budget.",
            }
        )
    except asyncio.CancelledError:
        if STATE.cancel_requested.is_set():
            _emit({"type": "cancelled", "taskId": task_id})
            raise
        # Harness/SDK sometimes cancels the host task on connection death
        # (notably 401). Treat as engine failure unless PATH asked to cancel.
        _diag("unexpected CancelledError without cancel_requested")
        _diag(traceback.format_exc())
        _emit(
            {
                "type": "failed",
                "taskId": task_id,
                "code": "AG1_ENGINE_CANCELLED",
                "message": "Engineering session terminated unexpectedly.",
            }
        )
    except Exception as exc:  # noqa: BLE001
        _diag(traceback.format_exc())
        msg = repr(exc)
        code = "ENGINE_ERROR"
        if "401" in msg or "authentication" in msg.lower() or "credentials" in msg.lower():
            code = "AG1_AUTH_FAILED"
        _emit(
            {
                "type": "failed",
                "taskId": task_id,
                "code": code,
                "message": msg[:800],
            }
        )
    finally:
        STATE.agent = None


def _isolate_protocol_stdin() -> int:
    """Dup Node's JSONL pipe off fd 0 so the Antigravity harness cannot steal it.

    The local harness is spawned with close_fds semantics that still inherit
    fds 0/1/2. If fd 0 remains the PATH↔bridge protocol pipe, the harness may
    read/close it and our asyncio readline sees EOF — which previously cancelled
    the engineering task mid-flight (false cancelled, hiding real auth/engine
    errors). Point fd 0 at /dev/null for children; read commands from the dup.
    """
    protocol_fd = os.dup(0)
    try:
        devnull = os.open(os.devnull, os.O_RDONLY)
        try:
            os.dup2(devnull, 0)
        finally:
            os.close(devnull)
    except OSError as exc:
        _diag(f"protocol stdin isolate failed: {exc!r}")
    return protocol_fd


async def _stdin_loop() -> None:
    protocol_fd = _isolate_protocol_stdin()
    loop = asyncio.get_running_loop()
    reader = asyncio.StreamReader()
    protocol = asyncio.StreamReaderProtocol(reader)
    proto_file = os.fdopen(protocol_fd, "rb", buffering=0, closefd=True)
    await loop.connect_read_pipe(lambda: protocol, proto_file)
    _diag("protocol stdin isolated from fd0")

    while True:
        line = await reader.readline()
        if not line:
            _diag("protocol stdin EOF")
            break
        raw = line.decode("utf-8", errors="replace").strip()
        if raw == "":
            continue
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            _diag(f"ignored non-json stdin line: {raw[:200]!r}")
            continue
        if not isinstance(msg, dict):
            _diag("ignored non-object stdin json")
            continue
        mtype = msg.get("type")
        if mtype == "start":
            if STATE.task and not STATE.task.done():
                _emit(
                    {
                        "type": "failed",
                        "taskId": msg.get("taskId"),
                        "code": "BUSY",
                        "message": "A task is already running.",
                    }
                )
                continue
            STATE.cancel_requested.clear()
            STATE.continue_event.clear()
            STATE.done_event.clear()
            STATE.continue_text = None
            STATE.task = asyncio.create_task(_run_engineering_task(msg))
        elif mtype == "continue":
            text = msg.get("text")
            STATE.continue_text = str(text) if text is not None else ""
            STATE.continue_event.set()
            _diag(f"continue command received chars={len(STATE.continue_text)}")
        elif mtype == "done":
            STATE.done_event.set()
            _diag("done command received")
        elif mtype == "cancel":
            _diag("cancel command received")
            STATE.cancel_requested.set()
            if STATE.task and not STATE.task.done():
                STATE.task.cancel()
        elif mtype == "close":
            _diag("close command received")
            STATE.done_event.set()
            STATE.cancel_requested.set()
            if STATE.task and not STATE.task.done():
                STATE.task.cancel()
                with contextlib.suppress(Exception):
                    await STATE.task
            break
        else:
            _diag(f"unknown command type: {mtype!r}")

    # Protocol EOF / loop end: wait for in-flight engineering to finish.
    # Do NOT cancel — orphan cleanup is the parent's close/cancel/SIGTERM job.
    # Cancelling on EOF was the false-cancelled production failure mode.
    if STATE.task and not STATE.task.done():
        _diag("protocol closed; awaiting in-flight engineering task")
        with contextlib.suppress(Exception):
            await STATE.task


def main() -> None:
    try:
        asyncio.run(_stdin_loop())
    except KeyboardInterrupt:
        _diag("interrupted")
        sys.exit(130)


if __name__ == "__main__":
    main()
