import { normalizeObjectiveText } from "../pathcode-cli/normalize-text.mjs";

/**
 * Detect PATH launch / preflight shell blocks (mirrors engineering-report helper
 * without importing it — avoids a state ↔ report cycle).
 * @param {string} text
 */
function looksLikeLauncherShell(text) {
  const raw = String(text || "").trim();
  if (!raw) return false;
  if (/rm\s+-rf\s+.*path-code\/runtime/i.test(raw)) return true;
  if (
    /PATHCODE_RUNTIME_ROOT|runtime-klar/i.test(raw) &&
    /^(cd |export |rm )/m.test(raw)
  ) {
    return true;
  }
  const lines = raw
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean);
  if (lines.length === 0) return false;
  const shellish = lines.filter((l) =>
    /^(cd |echo |rm |export |unset |mkdir |chmod |open |node scripts\/|PATHCODE_|git status)/i.test(
      l,
    ),
  );
  if (shellish.length >= Math.max(2, Math.ceil(lines.length * 0.6))) return true;
  if (
    lines.length <= 6 &&
    shellish.length === lines.length &&
    /cd |git status|rm -rf/i.test(raw)
  ) {
    return true;
  }
  return false;
}

/**
 * Loose preference score when choosing between objective candidates at lock time.
 * @param {string} text
 */
function scoreLooseObjective(text) {
  const t = String(text || "").trim();
  if (!t) return -1;
  let score = Math.min(t.length, 2000);
  if (looksLikeLauncherShell(t)) score -= 5000;
  if (/inspect|typecheck|test|assess|repair|find|risk|solid/i.test(t)) score += 200;
  return score;
}

/**
 * Path Studio — pure state reducer (PS1).
 *
 * READ-ONLY mirror of the session NDJSON seam. Every card maps to exactly one
 * real session.* event family and appears only when that event has arrived.
 * Never fabricates progress, percentages, ETAs, or success before its event.
 *
 * Integrity lock: renders exactly one sessionId at a time; events from any
 * other sessionId are ignored.
 */

/** Ordered state cards — engine sequence. */
export const STUDIO_CARD_ORDER = Object.freeze([
  "task",
  "preflight",
  "disclosure",
  "authority",
  "scope",
  "reading",
  "reasoning",
  "gate1",
  "edit",
  "recovery",
  "applying",
  "reobserved",
  "validationPlan",
  "validationRunning",
  "validationResult",
  "validationSkipped",
  "gate2",
  "terminal",
  "findings",
]);

/** @typedef {"pending" | "active" | "done" | "skipped" | "refused"} CardStatus */

/**
 * @returns {{
 *   sessionId: string | null,
 *   sinkEnded: boolean,
 *   cards: Record<string, { id: string, title: string, status: CardStatus, detail: string, arrived: boolean }>,
 *   heartbeat: { stage: string, elapsedMs: number } | null,
 *   acceptedTypes: string[],
 *   ignoredForeignCount: number,
 * }}
 */

function pushStreamHistory(state, entry) {
  if (!state?.product) return;
  if (!Array.isArray(state.product.streamHistory)) state.product.streamHistory = [];
  state.product.streamHistory.push(entry);
  state.product.lastActivityAt = Date.now();
  // Large enough for a full engineering session to remain scrollable after COMPLETE.
  if (state.product.streamHistory.length > 2000) {
    state.product.streamHistory = state.product.streamHistory.slice(-2000);
  }
}

/** Tool ids / tokens that must never appear as operator-facing path or command. */
const GARBAGE_TOKEN =
  /^(Code|View|Edit|Create|bash|sh|zsh|run_command|view_file|edit_file|create_file|list_directory|list_dir|find_file|search_directory|search_dir|inspect|tool|file|mcp)$/i;

function isGarbageToken(value) {
  return !value || GARBAGE_TOKEN.test(String(value).trim());
}

/**
 * Convert session timingMarks ("name:msFromStart") into report buckets.
 * @param {unknown[]} marks
 */
function summarizeTimingMarks(marks) {
  /** @type {Record<string, number>} */
  const buckets = {
    providerWait: 0,
    environment: 0,
    validation: 0,
    steering: 0,
    engineHandoff: 0,
    unclassified: 0,
    total: 0,
  };
  let prev = 0;
  for (const raw of marks) {
    const s = String(raw || "");
    const idx = s.lastIndexOf(":");
    if (idx <= 0) continue;
    const name = s.slice(0, idx);
    const ms = Number(s.slice(idx + 1));
    if (!Number.isFinite(ms) || ms < 0) continue;
    const delta = Math.max(0, ms - prev);
    prev = ms;
    buckets.total = Math.max(buckets.total, ms);
    if (/first_engine|provider|bridge|spawn|start/i.test(name)) {
      buckets.providerWait += delta;
    } else if (/env|prepar|depend|install/i.test(name)) {
      buckets.environment += delta;
    } else if (/valid/i.test(name)) {
      buckets.validation += delta;
    } else if (/steer/i.test(name)) {
      buckets.steering += delta;
    } else if (/handoff|collab|copilot|antigravity|repair/i.test(name)) {
      buckets.engineHandoff += delta;
    } else {
      buckets.unclassified += delta;
    }
  }
  return buckets;
}

export function createEmptyStudioState() {
  /** @type {Record<string, { id: string, title: string, status: CardStatus, detail: string, arrived: boolean }>} */
  const cards = {};
  const titles = {
    task: "Task",
    preflight: "Preflight",
    disclosure: "Disclosure / Policy",
    authority: "Authority",
    scope: "Scope",
    reading: "Reading",
    reasoning: "Reasoning",
    gate1: "Gate 1",
    edit: "Edit summary",
    recovery: "Recovery checkpoint",
    applying: "Applying",
    reobserved: "Re-observed",
    validationPlan: "Validation plan",
    validationRunning: "Validation running",
    validationResult: "Validation result",
    validationSkipped: "Validation skipped",
    gate2: "Gate 2",
    terminal: "Terminal disposition",
    findings: "Findings",
  };
  for (const id of STUDIO_CARD_ORDER) {
    cards[id] = {
      id,
      title: titles[id] ?? id,
      status: "pending",
      detail: "not yet",
      arrived: false,
    };
  }
  return {
    sessionId: null,
    sinkEnded: false,
    cards,
    heartbeat: null,
    acceptedTypes: [],
    ignoredForeignCount: 0,
    /** GC1-c living product projection (event-driven; never minted). */
    product: {
      pathPhase: "Idle",
      cloudFooter: null,
      region: null,
      projectFiles: /** @type {string[]} */ ([]),
      /** @type {Array<{ path: string, role: string }>} */
      projectEntries: [],
      branch: null,
      dirtySummary: null,
      unversioned: false,
      projectName: null,
      editableCount: 0,
      contextCount: 0,
      hydrationFiles: null,
      cloudSelected: false,
      workstationReady: false,
      disposed: false,
      infraFailure: null,
      modelId: null,
      providerLabel: null,
      providerTurn: null,
      /** @type {string[] | null} */
      machineLines: null,
      pathDetail: null,
      /** AG1 living product — when true, evidence uses engineering lifecycle. */
      ag1: false,
      ag1Mutation: false,
      /** @type {string[]} */
      ag1Activities: [],
      /** @type {Array<{ label: string, detail: string, path?: string, command?: string, diff?: string, output?: string, ok?: boolean, stat?: string }>} */
      recentOps: [],
      /** Open-canvas scrollable history (richer than recentOps). */
      streamHistory: [],
      shellCommandCount: 0,
      enginesUsed: [],
      streamScroll: 0,
      /** In-flight busy heartbeat (real work only). */
      busyLabel: null,
      busyDetail: null,
      busySince: null,
      /** Wall-clock of last real stream activity (for quiet-period heartbeat). */
      lastActivityAt: null,
      /** Wall-clock start of the active engineering task (for elapsed footer). */
      taskStartedAt: null,
      /** Accumulated user-facing narration for the final report. */
      narrationExcerpts: [],
      taskId: null,
      durationMs: null,
      enginesUsed: [],
      timingSummary: null,
      elapsedLabel: null,
      lastActivity: null,
      blockReason: null,
      /** Current observable detail (command/file) from a real tool event. */
      currentDetail: null,
      /** Primary vs task branch clarity. */
      primaryBranch: null,
      taskBranch: null,
      baselineSha: null,
      resultSha: null,
      changedFileTotal: 0,
      /** Provisional engine-time check feedback (tests/build while engineering). */
      engineCheckFeedback: null,
      finalValidationStarted: false,
      finalValidationComplete: false,
      /** Bounded presentation-only diff preview lines. */
      diffPreviewLines: /** @type {string[]} */ ([]),
      diffPreviewTruncated: false,
      diffPreviewShownFiles: 0,
      inspectCommand: null,
      preservedArtifact: null,
      /** Engineering handoff text (engine-derived; also feeds the completion report). */
      engineeringHandoff: null,
      /** Authoritative completion classification from session.engineering.result. */
      resultClassification: null,
      /** Terminal disposition code (VERIFIED / CANCELLED / …). */
      terminalDisposition: null,
      /** Plain-text completion report (same as /report + durable file). */
      engineeringReportPlain: null,
      /** Path to durable report beside task trace. */
      engineeringReportPath: null,
      /** Locked full PATH objective (never launcher shell / truncated preview). */
      taskObjective: null,
      /** True when the verified task advances the session base onto a task branch. */
      advancesSession: false,
      /** Visible /report confirmation inside the living canvas (not silent). */
      reportActionNotice: null,
      /** S2 slash-command reply panel (history / inspect / prefs / merge). */
      operatorPanel: null,
      /** Compact multi-task history inside the session-long cockpit. */
      sessionHistory: /** @type {Array<{ preview: string, classification: string }>} */ ([]),
      /** Idle prompt text rendered inside the cockpit frame. */
      cockpitPrompt: null,
      awaitingInput: false,
      /** PATH-owned composer buffer (never echoed via terminal). */
      composerText: "",
      composerScroll: 0,
      composerPasteActive: false,
      /** Last task preview for session history. */
      taskPreview: null,
      /** AG4 GitHub delivery projection. */
      deliveryPhase: null,
      /** @type {{ remote: string, baseBranch: string, taskBranch: string, status: string } | null} */
      deliveryApproval: null,
      /** @type {{ status: string, remote: string | null, prNumber: number | null, prUrl: string | null, remoteBranchOk: boolean, prOk: boolean, message: string | null } | null} */
      deliveryResult: null,
    },
  };
}

/**
 * Success dispositions that may legally render Complete (after cleanup when cloud).
 * @param {string} disposition
 * @param {string} [summary]
 */
export function isSuccessfulTerminalDisposition(disposition, summary = "") {
  const blob = `${disposition} ${summary}`;
  return /MUTATION_APPLIED_AND_CONFIGURED_VALIDATION_ACCEPTED|CONFIGURED VALIDATION ACCEPTED|EDIT APPLIED · CONFIGURED VALIDATION ACCEPTED/i.test(
    blob,
  );
}

/**
 * @param {string} disposition
 * @param {string} [summary]
 * @returns {"Complete"|"Failed"|"Blocked"|"Cancelled"|"Unknown"}
 */
export function classifyTerminalPathPhase(disposition, summary = "") {
  const blob = `${disposition} ${summary}`;
  if (/cancel|declined|CREDENTIAL_CANCELLED/i.test(blob)) return "Cancelled";
  if (
    /ESCALATION|AUTONOMY_ESCALATION|PRIMARY_MUTATED|cleanup\.pending|CLEANUP_PENDING|AG1_AUTH_REQUIRED|GIT_IDENTITY_REQUIRED|UNMERGED_INDEX/i.test(
      blob,
    )
  ) {
    return "Blocked";
  }
  // AG1 independent final result classifications — never map failure to Complete.
  const disp = String(disposition || "").trim();
  if (/^VERIFIED$/i.test(disp)) return "Verified";
  if (/^PARTIALLY_VERIFIED$/i.test(disp)) return "Partially verified";
  if (/^FAILED$/i.test(disp)) return "Failed";
  if (/^NOT_VERIFIED$/i.test(disp)) return "Not verified";
  if (/^AG1_/i.test(disp)) return "Failed";
  if (isSuccessfulTerminalDisposition(disposition, summary)) return "Complete";
  if (/UNKNOWN|^unknown$/i.test(disp)) return "Unknown";
  // Fail closed: non-success outcomes never render as Complete.
  if (
    /fail|error|refuse|not.?established|NOT_READY|ACQUIRE|CREDENTIAL|unavailable|GC1|ENV_POLICY|STALE|GAP|DRIFT|CALL_FAILED|AUTH_FAILED|SNAPSHOT|REQUIRED|UNAVAILABLE|INVENTORY|MUTATION_STALE|VALIDATION_|SCOPE_|ADAPTER_|BRAIN_|H_REFUSED|EDIT_|CHECK_/i.test(
      blob,
    )
  ) {
    return "Failed";
  }
  return "Failed";
}

/**
 * ONE authoritative PATH phase for PROJECT/PATH/EVIDENCE/footer — never optimistic Complete.
 * @param {ReturnType<typeof createEmptyStudioState>} state
 */
export function projectAuthoritativePathPhase(state) {
  const product = state.product || createEmptyStudioState().product;
  const terminal = state.cards?.terminal;
  const recorded = product.pathPhase || "Idle";

  if (product.infraFailure) {
    return "Infrastructure failure";
  }

  // AG4 delivery phases override the Verified terminal while publication is active.
  if (
    typeof product.deliveryPhase === "string" &&
    product.deliveryPhase.trim() !== ""
  ) {
    return product.deliveryPhase;
  }

  // Cloud mid-flight always wins over a premature terminal Complete.
  if (product.cloudSelected && !product.disposed) {
    if (/Cleaning up/i.test(recorded) || /Cleaning up/i.test(product.cloudFooter || "")) {
      return "Cleaning up";
    }
    if (/Starting workstation/i.test(recorded) || /Starting workstation/i.test(product.cloudFooter || "")) {
      if (terminal?.arrived) {
        const classified = classifyTerminalPathPhase(
          String(terminal.detail || ""),
          "",
        );
        if (classified !== "Complete") return classified === "Failed" && /EXECUTION_NOT_READY|ACQUIRE|Infrastructure/i.test(String(terminal.detail || ""))
          ? "Infrastructure failure"
          : classified === "Failed"
            ? "Failed"
            : classified;
      }
      return "Starting workstation";
    }
    if (/Hydrating/i.test(recorded)) return "Hydrating";
    if (/Preparing dependencies|Preparing environment/i.test(recorded)) {
      return recorded;
    }
  }

  if (terminal?.arrived) {
    const parts = String(terminal.detail || "").split(" — ");
    const disposition = parts[0] || terminal.detail || "";
    const summary = parts.slice(1).join(" — ");
    const classified = classifyTerminalPathPhase(disposition, summary);
    if (classified === "Complete" || classified === "Verified") {
      if (product.cloudSelected && !product.disposed) {
        return /Cleaning up/i.test(product.cloudFooter || "")
          ? "Cleaning up"
          : "Saving result";
      }
      if (state.cards.gate2?.arrived && state.cards.gate2.status !== "done") {
        return "Failed";
      }
      // AG1: Verified is the success terminal; legacy Complete remains for Gate2 success.
      return classified === "Verified" ? "Verified" : "Complete";
    }
    if (
      classified === "Failed" &&
      /EXECUTION_NOT_READY|ACQUIRE_FAILED|REMOTE_|Infrastructure|environment unavailable/i.test(
        `${disposition} ${summary}`,
      )
    ) {
      return "Infrastructure failure";
    }
    return classified;
  }

  if (
    state.cards.validationRunning?.status === "active" &&
    recorded !== "Investigating failure"
  ) {
    return "Testing";
  }

  return recorded;
}

/**
 * @param {string} relativePath
 * @param {{ editable?: boolean, context?: boolean, modified?: boolean }} flags
 */
function fileRole(relativePath, flags) {
  if (flags.modified) return "modified remotely";
  if (flags.editable) return "editable";
  const base = String(relativePath).split("/").pop() || "";
  if (/\.test\.|\.spec\.|_test\.|tests?\//i.test(relativePath)) return "validation";
  if (
    /^(package\.json|package-lock\.json|pnpm-lock\.yaml|yarn\.lock|tsconfig.*\.json|Cargo\.toml|go\.mod|pom\.xml|build\.gradle)/i.test(
      base,
    )
  ) {
    return "execution";
  }
  if (flags.context) return "context";
  return "support";
}

/**
 * @param {ReturnType<typeof createEmptyStudioState>} state
 * @param {string} cardId
 * @param {CardStatus} status
 * @param {string} detail
 */
function setCard(state, cardId, status, detail) {
  const card = state.cards[cardId];
  if (!card) return;
  card.status = status;
  card.detail = detail;
  card.arrived = true;
}

function setPathPhase(state, phase) {
  if (!state.product) return;
  state.product.pathPhase = phase;
}

function setCloudFooter(state, text) {
  if (!state.product) return;
  state.product.cloudFooter = text;
  if (text && /Disposed/i.test(text)) {
    state.product.disposed = true;
  }
}

/**
 * Apply one event. Foreign sessionId events are ignored (PS1-N).
 * First event with a sessionId binds the Studio view.
 *
 * @param {ReturnType<typeof createEmptyStudioState>} state
 * @param {Record<string, unknown>} event
 * @param {{ sessionId?: string | null, decorateGate2Accepted?: boolean }} [opts]
 * @returns {ReturnType<typeof createEmptyStudioState>}
 */
export function applyStudioEvent(state, event, opts = {}) {
  if (!event || typeof event.type !== "string") return state;

  const eventSid =
    typeof event.sessionId === "string" && event.sessionId.trim() !== ""
      ? event.sessionId.trim()
      : null;

  // Bind or filter by session id.
  const forced =
    typeof opts.sessionId === "string" && opts.sessionId.trim() !== ""
      ? opts.sessionId.trim()
      : null;
  if (state.sessionId === null) {
    state.sessionId = forced ?? eventSid;
  }
  const active = state.sessionId;
  if (active !== null && eventSid !== null && eventSid !== active) {
    state.ignoredForeignCount += 1;
    return state;
  }
  if (forced !== null && eventSid !== null && eventSid !== forced) {
    state.ignoredForeignCount += 1;
    return state;
  }

  const type = event.type;
  state.acceptedTypes.push(type);
  if (!state.product) {
    state.product = createEmptyStudioState().product;
  }

  switch (type) {
    case "session.task.received":
      setCard(
        state,
        "task",
        "done",
        typeof event.task === "string"
          ? event.task
          : typeof event.preview === "string"
            ? event.preview
            : "(task)",
      );
      if (event.mode === "ag1") {
        state.product.ag1 = true;
      }
      if (typeof state.product.taskStartedAt !== "number") {
        state.product.taskStartedAt = Date.now();
      }
      {
        // Prefer full `task` field; `preview` may be a legacy truncation.
        const raw =
          typeof event.task === "string" && event.task.trim()
            ? event.task
            : typeof event.preview === "string"
              ? event.preview
              : null;
        if (raw) {
          const normalized = normalizeObjectiveText(raw, { maxChars: 4000 });
          const locked =
            typeof state.product.taskObjective === "string"
              ? state.product.taskObjective
              : "";
          // Lock first authoritative objective. Expand only when a longer
          // version clearly extends a truncated lock (never replace with
          // unrelated launcher shell).
          if (!locked) {
            state.product.taskObjective = normalized;
          } else if (
            normalized.length > locked.length &&
            (normalized.startsWith(locked) ||
              locked.length <= 220 ||
              (looksLikeLauncherShell(locked) &&
                !looksLikeLauncherShell(normalized)))
          ) {
            state.product.taskObjective = normalized;
          } else if (
            looksLikeLauncherShell(locked) &&
            !looksLikeLauncherShell(normalized) &&
            scoreLooseObjective(normalized) > scoreLooseObjective(locked)
          ) {
            state.product.taskObjective = normalized;
          }
          state.product.taskPreview = state.product.taskObjective.slice(0, 4000);
          if (!Array.isArray(state.product.streamHistory)) state.product.streamHistory = [];
          const objectiveDetail = state.product.taskObjective;
          // Dedupe against any prior objective in this task stream — gateway and
          // session can both emit task.received with intervening preparing ops.
          const dup = state.product.streamHistory.some(
            (entry) =>
              entry &&
              entry.kind === "objective" &&
              typeof entry.detail === "string" &&
              entry.detail === objectiveDetail,
          );
          if (!dup) {
            state.product.streamHistory.push({
              kind: "objective",
              title: "Objective",
              detail: objectiveDetail,
            });
          }
          if (state.product.streamHistory.length > 200) {
            state.product.streamHistory = state.product.streamHistory.slice(-200);
          }
        }
      }
      state.product.awaitingInput = false;
      if (typeof event.modelId === "string") state.product.modelId = event.modelId;
      if (typeof event.provider === "string") {
        state.product.providerLabel = event.provider;
      }
      setPathPhase(state, "Understanding");
      break;
    case "session.preflight": {
      const branch = typeof event.branch === "string" ? event.branch : "?";
      const dirty = typeof event.dirtySummary === "string" ? event.dirtySummary : "?";
      setCard(state, "preflight", "done", `${branch}; ${dirty}`);
      state.product.branch = branch;
      state.product.primaryBranch = branch;
      state.product.dirtySummary = dirty;
      state.product.unversioned =
        event.unversioned === true || branch === "unversioned" || dirty === "unversioned";
      if (typeof event.head === "string" && /^[0-9a-f]{7,40}$/i.test(event.head)) {
        state.product.baselineSha = event.head;
      }
      if (typeof event.projectName === "string" && event.projectName.trim()) {
        state.product.projectName = event.projectName.trim();
      }
      if (state.product.unversioned) {
        pushStreamHistory(state, {
          kind: "prepare",
          title: "Unversioned project",
          detail: "existing project without Git — source control can be established as a task",
        });
      }
      setPathPhase(state, "Scoping");
      break;
    }
    case "session.disclosure":
      setCard(
        state,
        "disclosure",
        "done",
        typeof event.kind === "string" ? event.kind : "disclosed",
      );
      break;
    case "session.authority": {
      const gate = typeof event.gate === "string" ? event.gate : "authority";
      const how =
        typeof event.admission === "string" ? event.admission : "challenge-required";
      setCard(state, "authority", "done", `${gate} — ${how}`);
      break;
    }
    case "session.scope.admitted": {
      const editable = Array.isArray(event.editable) ? event.editable : [];
      const context = Array.isArray(event.context) ? event.context : [];
      setCard(
        state,
        "scope",
        "done",
        `editable: ${editable.length} context: ${context.length}`,
      );
      state.product.editableCount = editable.length;
      state.product.contextCount = context.length;
      const editableSet = new Set(editable.map(String));
      const contextSet = new Set(context.map(String));
      const files = [
        ...editable.map(String),
        ...context.map(String).filter((p) => !editableSet.has(p)),
      ];
      state.product.projectFiles = files.slice(0, 12);
      state.product.projectEntries = files.slice(0, 12).map((path) => ({
        path,
        role: fileRole(path, {
          editable: editableSet.has(path),
          context: contextSet.has(path),
        }),
      }));
      setPathPhase(state, "Scoping");
      break;
    }
    case "session.reading": {
      const files = Array.isArray(event.files) ? event.files : [];
      setCard(state, "reading", "done", files.join(", ") || "reading");
      state.heartbeat = null;
      break;
    }
    case "session.reasoning": {
      const n = typeof event.call === "number" ? event.call : "?";
      const of = typeof event.of === "number" ? event.of : "?";
      setCard(state, "reasoning", "active", `call ${n} of ${of}`);
      state.product.providerTurn = { call: n, of };
      if (typeof event.modelId === "string") {
        state.product.modelId = event.modelId;
      }
      if (typeof event.provider === "string") {
        state.product.providerLabel = event.provider;
      }
      setPathPhase(state, "Understanding");
      break;
    }
    case "session.gate1":
      if (event.status === "grounded") {
        setCard(state, "gate1", "done", "grounded");
      } else {
        setCard(state, "gate1", "refused", String(event.code ?? "refused"));
      }
      state.heartbeat = null;
      break;
    case "session.edit.summary": {
      const path = typeof event.path === "string" ? event.path : "(file)";
      const before = typeof event.beforeBytes === "number" ? event.beforeBytes : 0;
      const after = typeof event.afterBytes === "number" ? event.afterBytes : 0;
      const prev = state.cards.edit.arrived ? `${state.cards.edit.detail}; ` : "";
      setCard(state, "edit", "done", `${prev}${path} ${before}→${after} bytes`);
      setPathPhase(state, "Correcting");
      break;
    }
    case "session.recovery.checkpoint":
    case "session.checkpoint.ready":
      setCard(
        state,
        "recovery",
        "done",
        `id ${event.id ?? "?"} — ${event.status ?? "READY"}`,
      );
      setPathPhase(state, "Checkpointing");
      break;
    case "session.applying": {
      const files = Array.isArray(event.files) ? event.files : [];
      setCard(state, "applying", "active", `${files.length} file(s)`);
      setPathPhase(state, "Applying");
      if (files.length > 0) {
        const first = String(files[0]);
        state.product.pathDetail = first;
        const entries = Array.isArray(state.product.projectEntries)
          ? state.product.projectEntries
          : [];
        state.product.projectEntries = entries.map((e) =>
          files.map(String).includes(e.path)
            ? { ...e, role: "modified remotely" }
            : e,
        );
      }
      break;
    }
    case "session.reobserved":
      setCard(state, "reobserved", "done", "re-observed");
      state.heartbeat = null;
      if (state.cards.applying.arrived) {
        state.cards.applying.status = "done";
      }
      setPathPhase(state, "Verifying");
      break;
    case "session.validation.plan": {
      const checks = Array.isArray(event.checks) ? event.checks : [];
      setCard(state, "validationPlan", "done", `${checks.length} check(s)`);
      state.product.finalValidationStarted = true;
      state.product.engineCheckFeedback = null;
      // Reset provisional check rows; project checks accumulate from here.
      state.product.ag1Checks = [];
      setPathPhase(state, "Verifying");
      break;
    }
    case "session.validation.running":
      setCard(
        state,
        "validationRunning",
        "active",
        typeof event.check === "string" ? event.check : "running",
      );
      state.product.finalValidationStarted = true;
      setPathPhase(state, "Verifying");
      break;
    case "session.validation.result": {
      const check = typeof event.check === "string" ? event.check : "check";
      const status = typeof event.status === "string" ? event.status : "?";
      const prev = state.cards.validationResult.arrived
        ? `${state.cards.validationResult.detail}; `
        : "";
      setCard(state, "validationResult", "done", `${prev}${check} — ${status}`);
      if (state.cards.validationRunning.arrived) {
        state.cards.validationRunning.status = "done";
      }
      // Only accumulate AG1 check rows on the Antigravity product path.
      if (state.product.ag1 === true) {
        if (!Array.isArray(state.product.ag1Checks)) state.product.ag1Checks = [];
        state.product.ag1Checks.push({
          id: check,
          kind: typeof event.kind === "string" ? event.kind : check,
          ok: event.ok === true || status === "PASSED",
        });
      }
      state.heartbeat = null;
      state.product.finalValidationStarted = true;
      if (/fail|error|not.?pass/i.test(status)) {
        setPathPhase(state, "Investigating failure");
      } else {
        setPathPhase(state, "Verifying");
      }
      break;
    }
    case "session.validation.skipped":
      setCard(
        state,
        "validationSkipped",
        "skipped",
        typeof event.reason === "string" ? event.reason : "skipped",
      );
      // Honesty: do not invent running/result/gate2 success.
      state.heartbeat = null;
      break;
    case "session.gate2":
      if (event.status === "accepted") {
        setCard(state, "gate2", "done", "accepted");
      } else {
        setCard(state, "gate2", "refused", "not-established");
      }
      state.heartbeat = null;
      break;
    case "session.terminal": {
      const disposition =
        typeof event.disposition === "string" ? event.disposition : "unknown";
      const summary = typeof event.summary === "string" ? event.summary : "";
      setCard(
        state,
        "terminal",
        "done",
        summary ? `${disposition} — ${summary}` : disposition,
      );
      state.heartbeat = null;
      const classified = classifyTerminalPathPhase(disposition, summary);
      state.product.terminalSummary = summary || disposition;
      state.product.blockReason = summary || disposition;
      state.product.terminalDisposition = disposition;
      state.product.busyLabel = null;
      state.product.busyDetail = null;
      state.product.busySince = null;
      // Follow latest so the completion report is visible (not buried under scroll).
      state.product.streamScroll = 0;
      // Surface the real outcome in the open-canvas stream (never a silent DONE).
      pushStreamHistory(state, {
        kind: "terminal",
        title:
          classified === "Verified" || classified === "Complete"
            ? "Complete"
            : classified === "Cancelled"
              ? "Stopped"
              : classified === "Blocked"
                ? "Blocked"
                : classified === "Partially verified"
                  ? "Partial"
                  : "Failed",
        detail: summary || disposition,
        ok:
          classified === "Verified" ||
          classified === "Complete" ||
          classified === "Partially verified",
      });
      if (classified === "Complete" && state.product.cloudSelected && !state.product.disposed) {
        setPathPhase(state, "Saving result");
      } else if (
        classified === "Failed" &&
        /EXECUTION_NOT_READY|ACQUIRE|REMOTE_|environment unavailable|Infrastructure/i.test(
          `${disposition} ${summary}`,
        )
      ) {
        state.product.infraFailure =
          summary || disposition || "execution environment unavailable";
        setPathPhase(state, "Infrastructure failure");
      } else {
        setPathPhase(state, classified);
      }
      break;
    }
    case "session.engineering.report": {
      state.product.ag1 = true;
      if (typeof event.plain === "string" && event.plain.trim()) {
        state.product.engineeringReportPlain = event.plain;
      }
      if (typeof event.path === "string" && event.path.trim()) {
        state.product.engineeringReportPath = event.path.trim();
      }
      if (typeof event.disposition === "string" && event.disposition.trim()) {
        state.product.terminalDisposition = event.disposition.trim();
      }
      // Pin follow-latest so the report section is on screen.
      state.product.streamScroll = 0;
      break;
    }
    case "session.finding": {
      const message = typeof event.message === "string" ? event.message : "";
      const prev = state.cards.findings.arrived ? `${state.cards.findings.detail}\n` : "";
      setCard(state, "findings", "done", `${prev}${message}`.trim());
      break;
    }
    case "session.cancelled":
      setCard(state, "terminal", "refused", "cancelled");
      state.heartbeat = null;
      setPathPhase(state, "Cancelled");
      break;
    case "session.internal_error":
      setCard(
        state,
        "findings",
        "done",
        typeof event.message === "string" ? event.message : "internal error",
      );
      setPathPhase(state, "Failed");
      break;
    case "session.heartbeat": {
      const stage = typeof event.stage === "string" ? event.stage : "stage";
      const elapsedMs = typeof event.elapsedMs === "number" ? event.elapsedMs : 0;
      // Liveness only — never invent a percentage or filling bar.
      state.heartbeat = { stage, elapsedMs };
      break;
    }
    case "session.cloud.selected": {
      state.product.cloudSelected = true;
      if (typeof event.region === "string") state.product.region = event.region;
      setPathPhase(state, "Preparing environment");
      setCloudFooter(
        state,
        `☁ ${event.region || "cloud"} · Engineering Image · Selected`,
      );
      break;
    }
    case "session.environment.preparing": {
      setPathPhase(state, "Starting workstation");
      const config = typeof event.config === "string" ? event.config : "workstation";
      setCloudFooter(state, `☁ Starting workstation · ${config}`);
      break;
    }
    case "session.workstation.ready": {
      setPathPhase(state, "Preparing environment");
      state.product.workstationReady = true;
      setCloudFooter(
        state,
        `☁ ${state.product.region || "europe-west4"} · Engineering Image · Ready`,
      );
      break;
    }
    case "session.machine.capabilities": {
      const lines = Array.isArray(event.lines)
        ? event.lines.map(String)
        : null;
      if (lines && lines.length > 0) {
        state.product.machineLines = lines;
      }
      break;
    }
    case "session.hydration": {
      setPathPhase(state, "Hydrating");
      const files = typeof event.files === "number" ? event.files : null;
      state.product.hydrationFiles = files;
      const bytes =
        typeof event.bytes === "number" ? event.bytes : null;
      state.product.pathDetail =
        files != null
          ? `${files} files${bytes != null ? ` · ${(bytes / 1024).toFixed(1)} KB` : ""}`
          : null;
      setCloudFooter(
        state,
        `☁ ${state.product.region || "europe-west4"} · Engineering Image · Hydrating${
          files != null ? ` · ${files} file(s)` : ""
        }`,
      );
      break;
    }
    case "session.artifacts.saving":
      setPathPhase(state, "Saving artifacts");
      setCloudFooter(state, `☁ Saving artifacts…`);
      break;
    case "session.cleanup":
      setPathPhase(state, "Cleaning up");
      setCloudFooter(state, "☁ Cleaning up…");
      break;
    case "session.cleanup.pending":
      setPathPhase(state, "Blocked");
      setCloudFooter(state, "☁ Cleanup pending");
      break;
    case "session.workstation.disposed":
      setCloudFooter(state, "☁ Disposed ✓");
      state.product.disposed = true;
      // Promote deferred Complete only after dispose when terminal was successful.
      if (state.cards.terminal?.arrived) {
        const parts = String(state.cards.terminal.detail || "").split(" — ");
        if (isSuccessfulTerminalDisposition(parts[0] || "", parts.slice(1).join(" — "))) {
          if (
            !state.cards.gate2?.arrived ||
            state.cards.gate2.status === "done"
          ) {
            setPathPhase(state, "Complete");
          }
        }
      }
      break;
    case "session.engineering.workspace": {
      state.product.ag1 = true;
      setCard(
        state,
        "recovery",
        "done",
        typeof event.baselineHead === "string"
          ? `baseline ${event.baselineHead.slice(0, 12)}`
          : "task workspace",
      );
      if (typeof event.taskId === "string" && event.taskId.trim()) {
        state.product.taskId = event.taskId.trim();
      }
      if (typeof event.taskBranch === "string" && event.taskBranch.trim()) {
        state.product.taskBranch = event.taskBranch.trim();
      }
      if (typeof event.baselineHead === "string" && /^[0-9a-f]{7,40}$/i.test(event.baselineHead)) {
        state.product.baselineSha = event.baselineHead;
      }
      setPathPhase(state, "Understanding");
      break;
    }
    case "session.engineering.bridge": {
      state.product.ag1 = true;
      // Bridge/spawn diagnostics stay off the operator-facing detail lines.
      break;
    }
    case "session.engineering.activity": {
      state.product.ag1 = true;
      const activity =
        typeof event.activity === "string" ? event.activity : "";
      const label =
        typeof event.label === "string"
          ? event.label
          : activity || "Working";
      const detail =
        typeof event.detail === "string" ? event.detail.slice(0, 160) : null;
      // Engine "complete" is activity only — product terminal comes from session.result / checks.
      if (/^complete$/i.test(activity) || /^complete$/i.test(label)) {
        setPathPhase(state, "Finishing");
        break;
      }
      if (/^failed$/i.test(activity) || /^failed$/i.test(label)) {
        setPathPhase(state, "Failed");
        if (detail) state.product.currentDetail = detail;
        break;
      }
      // Honest general state when label is vague.
      const phaseLabel =
        label && label.trim() ? label : "Working";
      setPathPhase(state, phaseLabel);
      if (detail) state.product.currentDetail = detail;
      if (/edit|implement/i.test(phaseLabel)) {
        setCard(state, "applying", "active", phaseLabel);
        state.product.ag1Mutation = true;
      } else if (/inspect|read|understand/i.test(phaseLabel)) {
        setCard(state, "reading", "active", phaseLabel);
      } else if (/repair|correct/i.test(phaseLabel)) {
        state.product.ag1Mutation = true;
      } else if (/test/i.test(phaseLabel) && !/verif/i.test(phaseLabel)) {
        state.product.engineCheckFeedback = "running";
      }
      if (!Array.isArray(state.product.ag1Activities)) {
        state.product.ag1Activities = [];
      }
      if (state.product.ag1Activities[state.product.ag1Activities.length - 1] !== phaseLabel) {
        state.product.ag1Activities.push(phaseLabel);
      }
      if (!Array.isArray(state.product.recentOps)) state.product.recentOps = [];
      const lastOp = state.product.recentOps[state.product.recentOps.length - 1];
      if (!lastOp || lastOp.label !== phaseLabel || (detail && lastOp.detail !== detail)) {
        state.product.recentOps.push({
          label: phaseLabel,
          detail: detail || "",
        });
        if (state.product.recentOps.length > 80) {
          state.product.recentOps = state.product.recentOps.slice(-80);
        }
        // Prefer real command/path detail over opaque phase labels.
        const toolishDetail = detail && isGarbageToken(detail);
        const realEvidence =
          detail &&
          !toolishDetail &&
          (detail.includes(" ") ||
            detail.includes("/") ||
            detail.includes(".") ||
            detail.length > 12);
        const streamTitle = realEvidence
          ? /npm\s+(test|run\s+test)|vitest|jest|pytest|go test|cargo test/i.test(
              detail,
            )
            ? "Test"
            : /tsc|typecheck|mypy/i.test(detail)
              ? "Typecheck"
              : /eslint|lint/i.test(detail)
                ? "Lint"
                : /build|compile/i.test(detail)
                  ? "Build"
                  : /install|pnpm|yarn|pip /i.test(detail)
                    ? "Install"
                    : phaseLabel
          : phaseLabel;
      const vaguePhase =
          /^(Researching|Inspecting|Running command|Collaborating|Understanding|Working|Idle|Finishing|Waiting for engineering result)$/i.test(
            phaseLabel,
          ) && !realEvidence;
        if (
          !vaguePhase &&
          !toolishDetail &&
          !/^(Working|Idle)$/i.test(streamTitle) &&
          (!state.product.streamHistory?.length ||
            state.product.streamHistory[state.product.streamHistory.length - 1]
              ?.title !== streamTitle ||
            state.product.streamHistory[state.product.streamHistory.length - 1]
              ?.detail !== (detail || ""))
        ) {
          pushStreamHistory(state, {
            kind: "activity",
            title: streamTitle,
            detail: detail || "",
            command: realEvidence ? detail : undefined,
          });
        }
        if (realEvidence) {
          state.product.busyLabel = streamTitle;
          state.product.busyDetail = detail;
          state.product.busySince = Date.now();
        } else if (
          /^(Waiting for engineering result|Understanding)$/i.test(phaseLabel)
        ) {
          state.product.busyLabel = "Waiting for engineering result";
          state.product.busyDetail = detail || null;
          state.product.busySince = state.product.busySince || Date.now();
        }
      }
      break;
    }
    case "session.engineering.busy": {
      state.product.ag1 = true;
      if (event.clear === true) {
        state.product.busyLabel = null;
        state.product.busyDetail = null;
        state.product.busySince = null;
        break;
      }
      const label =
        typeof event.label === "string" && event.label.trim()
          ? event.label.trim()
          : "Working";
      const detail =
        typeof event.detail === "string" ? event.detail.slice(0, 200) : "";
      state.product.busyLabel = label;
      state.product.busyDetail = detail || null;
      state.product.busySince =
        typeof event.since === "number" ? event.since : Date.now();
      setPathPhase(state, label);
      break;
    }
    case "session.engineering.narration": {
      state.product.ag1 = true;
      const text =
        typeof event.text === "string"
          ? event.text.trim()
          : Array.isArray(event.paragraphs)
            ? event.paragraphs.filter((p) => typeof p === "string").join("\n\n")
            : "";
      if (!text) break;
      state.product.busyLabel = null;
      state.product.busyDetail = null;
      state.product.busySince = null;
      if (!Array.isArray(state.product.narrationExcerpts)) {
        state.product.narrationExcerpts = [];
      }
      state.product.narrationExcerpts.push(text.slice(0, 1_200));
      if (state.product.narrationExcerpts.length > 24) {
        state.product.narrationExcerpts =
          state.product.narrationExcerpts.slice(-24);
      }
      pushStreamHistory(state, {
        kind: "narration",
        title: "PATH",
        detail: text.slice(0, 2_000),
      });
      state.product.currentDetail = text.split("\n")[0].slice(0, 120);
      break;
    }
    case "session.operator.note": {
      state.product.ag1 = true;
      const text =
        typeof event.text === "string" ? event.text.trim().slice(0, 400) : "";
      if (!text) break;
      pushStreamHistory(state, {
        kind: "operator",
        title: "You",
        detail: text,
      });
      break;
    }
    case "session.engineering.steer": {
      state.product.ag1 = true;
      const phase =
        typeof event.phase === "string" && event.phase.trim()
          ? event.phase.trim()
          : "received";
      const text =
        typeof event.text === "string" ? event.text.trim().slice(0, 400) : "";
      pushStreamHistory(state, {
        kind: "steer",
        title: "Guidance",
        phase,
        detail: text || phase,
      });
      if (phase === "applying") {
        state.product.busyLabel = "Applying your guidance";
        state.product.busyDetail = text || null;
        state.product.busySince = Date.now();
      }
      break;
    }
    case "session.engineering.tool": {
      state.product.ag1 = true;
      const summary =
        typeof event.summary === "string"
          ? event.summary
          : typeof event.tool === "string"
            ? event.tool
            : "tool";
      const kind = typeof event.kind === "string" ? event.kind : "";
      const tool = typeof event.tool === "string" ? event.tool : "";
      let streamPath =
        typeof event.path === "string" && !isGarbageToken(event.path)
          ? event.path.replace(/^\.\//, "")
          : "";
      let streamCommand =
        typeof event.command === "string" && event.command.trim()
          ? event.command.trim()
          : "";
      let streamOutput =
        typeof event.output === "string" ? event.output : undefined;
      const streamQuery =
        typeof event.query === "string" && event.query.trim()
          ? event.query.trim()
          : "";
      let streamPreview =
        typeof event.preview === "string" ? event.preview : undefined;

      if (
        !streamCommand &&
        (kind === "command" ||
          kind === "test" ||
          kind === "shell" ||
          /run_command/i.test(tool) ||
          /run_command/i.test(summary))
      ) {
        const m =
          summary.match(/CommandLine[=:\s]+([^\n]+)/i) ||
          summary.match(/run_command\s+([^\n]+)/i);
        const candidate = (m?.[1] || "").trim();
        const looksLikeOutput =
          !candidate ||
          /^[✔✖ℹ✓✗]/.test(candidate) ||
          /^(PASS|FAIL|ok|tests?\s+\d|suites?\s+\d|env:)/i.test(candidate) ||
          summary.includes("\n");
        if (!looksLikeOutput) streamCommand = candidate.slice(0, 500);
      }

      if (!streamPath) {
        const pathMatch =
          summary.match(
            /(?:view_file|edit_file|create_file)\s+(?:View\s+|Edit\s+|Create\s+)?([^\s]+)/i,
          ) ||
          summary.match(
            /(?:^|\s)((?:src|test|tests|lib|scripts|docs|app|packages)\/[^\s]+)/,
          ) ||
          summary.match(/(?:^|\s)([^\s]+?\.[A-Za-z0-9]{1,12})\b/);
        const candidate = pathMatch?.[1] ? String(pathMatch[1]).replace(/^\.\//, "") : "";
        if (candidate && !isGarbageToken(candidate)) streamPath = candidate;
      }

      /** Human engineering titles — never abstract tool ids. */
      let streamTitle = "Working";
      if (
        kind === "command" ||
        kind === "test" ||
        kind === "shell" ||
        /run_command/i.test(tool) ||
        streamCommand
      ) {
        const cmdBlob = `${streamCommand} ${summary}`;
        const shortCmd = (streamCommand || "")
          .replace(/\s+/g, " ")
          .trim()
          .slice(0, 48);
        streamTitle =
          kind === "test" ||
          /npm test|vitest|pytest|jest|go test|cargo test|node --test/i.test(cmdBlob)
            ? "Test"
            : /tsc|typecheck|mypy/i.test(cmdBlob)
              ? "Typecheck"
              : /eslint|lint|clippy/i.test(cmdBlob)
                ? "Lint"
                : /build|compile|cargo build|mvn package/i.test(cmdBlob)
                  ? "Build"
                  : shortCmd
                    ? `Run ${shortCmd}`
                    : "Run";
        setPathPhase(
          state,
          streamTitle === "Test"
            ? "Testing"
            : streamTitle.startsWith("Run ")
              ? "Running command"
              : streamTitle,
        );
        if (streamTitle === "Test") state.product.engineCheckFeedback = "running";
        state.product.shellCommandCount =
          (typeof state.product.shellCommandCount === "number"
            ? state.product.shellCommandCount
            : 0) + 1;
      } else if (kind === "file_edit" || /edit_file|create_file/i.test(tool)) {
        streamTitle = /create_file/i.test(tool) ? "Create" : "Update";
        setCard(state, "edit", "done", streamPath || "edit");
        state.product.ag1Mutation = true;
        if (streamPath && !state.product.projectFiles.includes(streamPath)) {
          state.product.projectFiles.push(streamPath);
          state.product.projectEntries.push({ path: streamPath, role: "modified" });
        }
      } else if (/list_dir|list_directory/i.test(tool)) {
        streamTitle = "Inspect directory";
      } else if (/find_file|search_dir|search_directory|grep|ripgrep/i.test(tool) || streamQuery) {
        streamTitle = "Search";
      } else if (kind === "inspect" || /view_file/i.test(tool)) {
        streamTitle = "Read";
        if (streamPath) {
          if (!state.product.projectFiles.includes(streamPath)) {
            state.product.projectFiles.push(streamPath);
          }
        }
      } else if (kind === "mcp") {
        streamTitle = "MCP";
      }

      const detail =
        streamCommand ||
        streamQuery ||
        streamPath ||
        (summary.split(/\r?\n/, 1)[0] || "").slice(0, 120);

      state.product.currentDetail = detail.slice(0, 120);
      state.product.pathDetail = detail.slice(0, 80);
      if (!Array.isArray(state.product.recentOps)) state.product.recentOps = [];
      state.product.recentOps.push({
        label: streamTitle,
        detail: streamCommand || streamPath || detail,
        path: streamPath || undefined,
        command: streamCommand || undefined,
      });
      if (state.product.recentOps.length > 80) {
        state.product.recentOps = state.product.recentOps.slice(-80);
      }
      pushStreamHistory(state, {
        kind: kind || "tool",
        title: streamTitle,
        detail: streamQuery
          ? streamQuery
          : streamCommand
            ? ""
            : isGarbageToken(detail)
              ? ""
              : detail,
        path: streamPath || undefined,
        command: streamCommand || undefined,
        query: streamQuery || undefined,
        diff: typeof event.diff === "string" ? event.diff : undefined,
        preview: streamPreview,
        output: streamOutput,
        added: typeof event.added === "number" ? event.added : undefined,
        removed: typeof event.removed === "number" ? event.removed : undefined,
        ok: typeof event.ok === "boolean" ? event.ok : undefined,
        engine: typeof event.engine === "string" ? event.engine : undefined,
      });
      state.product.busyLabel = null;
      state.product.busyDetail = null;
      state.product.busySince = null;
      break;
    }
    case "session.capability.discovered": {
      state.product.ag1 = true;
      const matrix =
        event.matrix && typeof event.matrix === "object" ? event.matrix : null;
      const langs = Array.isArray(matrix?.languages)
        ? matrix.languages
            .filter((l) => l?.status === "ready")
            .map((l) => l.id)
        : [];
      const tools = Array.isArray(matrix?.toolchains)
        ? matrix.toolchains
            .filter((t) => t?.status === "ready")
            .map((t) => t.id)
        : [];
      const noteParts = [];
      if (langs.length) noteParts.push(langs.slice(0, 3).join(","));
      if (tools.length) noteParts.push(tools.slice(0, 3).join(","));
      const detail = noteParts.length
        ? `capability ${noteParts.join(" · ")}`.slice(0, 96)
        : "capability plane";
      if (!Array.isArray(state.product.recentOps)) state.product.recentOps = [];
      state.product.recentOps.push({ label: "Capability", detail });
      if (state.product.recentOps.length > 48) {
        state.product.recentOps = state.product.recentOps.slice(-48);
      }
      const envBits = [...langs.slice(0, 4), ...tools.slice(0, 4)].filter(Boolean);
      pushStreamHistory(state, {
        kind: "environment",
        title: "Environment ready",
        detail: envBits.length ? envBits.join(" · ") : detail,
      });
      break;
    }
    case "session.capability.mcp": {
      state.product.ag1 = true;
      const enabled = typeof event.enabled === "number" ? event.enabled : 0;
      const denied = typeof event.denied === "number" ? event.denied : 0;
      if (!Array.isArray(state.product.recentOps)) state.product.recentOps = [];
      state.product.recentOps.push({
        label: "MCP",
        detail: `enabled ${enabled} · denied ${denied}`,
      });
      if (state.product.recentOps.length > 48) {
        state.product.recentOps = state.product.recentOps.slice(-48);
      }
      break;
    }
    case "session.capability.advisory": {
      state.product.ag1 = true;
      const label =
        typeof event.label === "string" && event.label.trim()
          ? event.label.trim()
          : "Engineering review";
      const detail =
        typeof event.detail === "string" ? event.detail.slice(0, 96) : "";
      setPathPhase(state, label);
      if (detail) state.product.currentDetail = detail;
      if (!Array.isArray(state.product.recentOps)) state.product.recentOps = [];
      state.product.recentOps.push({ label, detail });
      if (state.product.recentOps.length > 48) {
        state.product.recentOps = state.product.recentOps.slice(-48);
      }
      break;
    }
    case "session.capability.collaborate": {
      state.product.ag1 = true;
      const engine =
        typeof event.engine === "string" && event.engine.trim()
          ? event.engine.trim()
          : "peer";
      const phase =
        typeof event.phase === "string" ? event.phase.trim() : "";
      // PATH owns the product narrative — provider names stay in detail/trace.
      const title =
        phase === "repair" || /repair/i.test(String(event.detail || ""))
          ? "Repairing"
          : phase === "done"
            ? "Repair complete"
            : phase === "notes"
              ? "Sharing engineering notes"
              : phase === "handoff" || phase === "resumed"
                ? "Continuing"
                : phase === "fallback" || phase === "error"
                  ? "Continuing with peer engine"
                  : "Continuing engineering";
      const detailRaw =
        typeof event.detail === "string" ? event.detail.trim() : "";
      const detail =
        detailRaw &&
        !/engineering turn$/i.test(detailRaw) &&
        !/^(copilot|antigravity)\b/i.test(detailRaw)
          ? detailRaw.slice(0, 160)
          : phase === "repair" || /repair/i.test(detailRaw)
            ? "repairing validation failures"
            : phase === "notes"
              ? "sharing engineering notes"
              : phase === "turn"
                ? "inspecting and editing in the task workspace"
                : detailRaw.slice(0, 160) || "collaborating in the task workspace";
      setPathPhase(state, title);
      state.product.currentDetail = detail;
      if (!Array.isArray(state.product.recentOps)) state.product.recentOps = [];
      state.product.recentOps.push({ label: title, detail, engine });
      if (state.product.recentOps.length > 80) {
        state.product.recentOps = state.product.recentOps.slice(-80);
      }
      pushStreamHistory(state, {
        kind: "collaborate",
        title,
        detail,
        engine,
      });
      if (!Array.isArray(state.product.enginesUsed)) state.product.enginesUsed = [];
      if (!state.product.enginesUsed.includes(engine)) {
        state.product.enginesUsed.push(engine);
      }
      break;
    }
    case "session.capability.preparing": {
      state.product.ag1 = true;
      setPathPhase(state, "Preparing environment");
      const detail =
        typeof event.detail === "string"
          ? event.detail.slice(0, 96)
          : "resolving engineering environment";
      state.product.currentDetail = detail;
      if (!Array.isArray(state.product.recentOps)) state.product.recentOps = [];
      state.product.recentOps.push({
        label: "Preparing environment",
        detail,
      });
      if (state.product.recentOps.length > 48) {
        state.product.recentOps = state.product.recentOps.slice(-48);
      }
      pushStreamHistory(state, {
        kind: "prepare",
        title: "Preparing environment",
        detail,
      });
      break;
    }
    case "session.capability.provisioning": {
      state.product.ag1 = true;
      const phase =
        typeof event.phase === "string" ? event.phase : "toolchains";
      const label =
        phase === "language-servers"
          ? "Preparing language intelligence"
          : phase === "indexing"
            ? "Indexing"
            : "Preparing environment";
      const detail =
        typeof event.detail === "string"
          ? event.detail.slice(0, 96)
          : String(phase).slice(0, 96);
      setPathPhase(state, label);
      state.product.currentDetail = detail;
      if (!Array.isArray(state.product.recentOps)) state.product.recentOps = [];
      state.product.recentOps.push({ label, detail });
      if (state.product.recentOps.length > 48) {
        state.product.recentOps = state.product.recentOps.slice(-48);
      }
      break;
    }
    case "session.capability.ready": {
      state.product.ag1 = true;
      const detail =
        typeof event.detail === "string"
          ? event.detail.slice(0, 96)
          : "engineering environment ready";
      if (!Array.isArray(state.product.recentOps)) state.product.recentOps = [];
      state.product.recentOps.push({
        label: "Environment ready",
        detail,
      });
      if (state.product.recentOps.length > 48) {
        state.product.recentOps = state.product.recentOps.slice(-48);
      }
      break;
    }
    case "session.capability.indexing": {
      state.product.ag1 = true;
      setPathPhase(state, "Indexing");
      const detail =
        typeof event.detail === "string"
          ? event.detail.slice(0, 96)
          : "building code index";
      state.product.currentDetail = detail;
      if (!Array.isArray(state.product.recentOps)) state.product.recentOps = [];
      state.product.recentOps.push({ label: "Indexing", detail });
      if (state.product.recentOps.length > 48) {
        state.product.recentOps = state.product.recentOps.slice(-48);
      }
      break;
    }
    case "session.engineering.handoff": {
      state.product.ag1 = true;
      if (typeof event.summary === "string" && event.summary.trim()) {
        const summary = event.summary.trim().slice(0, 1_200);
        state.product.engineeringHandoff = summary.slice(0, 400);
        // Surface engine handoff on the open canvas when narration did not already.
        const last = state.product.streamHistory?.[
          state.product.streamHistory.length - 1
        ];
        const already =
          last &&
          last.kind === "narration" &&
          typeof last.detail === "string" &&
          last.detail.includes(summary.slice(0, 80));
        if (!already) {
          if (!Array.isArray(state.product.narrationExcerpts)) {
            state.product.narrationExcerpts = [];
          }
          state.product.narrationExcerpts.push(summary);
          if (state.product.narrationExcerpts.length > 24) {
            state.product.narrationExcerpts =
              state.product.narrationExcerpts.slice(-24);
          }
          pushStreamHistory(state, {
            kind: "narration",
            title: "PATH",
            detail: summary,
          });
        }
      }
      break;
    }
    case "session.engineering.result": {
      state.product.ag1 = true;
      state.product.finalValidationStarted = true;
      state.product.finalValidationComplete = true;
      state.product.engineCheckFeedback = null;
      state.product.awaitingInput = false;
      if (Array.isArray(event.checks)) {
        state.product.ag1Checks = event.checks.map((c) => ({
          id: typeof c?.id === "string" ? c.id : "",
          kind: typeof c?.kind === "string" ? c.kind : "",
          ok: c?.ok === true,
        }));
      }
      const classification =
        typeof event.classification === "string"
          ? event.classification
          : "NOT_VERIFIED";
      const files = Array.isArray(event.changedFiles)
        ? event.changedFiles.filter((f) => typeof f === "string" && f.trim())
        : [];
      state.product.changedFileTotal = files.length;
      if (typeof event.taskBranch === "string" && event.taskBranch.trim()) {
        state.product.taskBranch = event.taskBranch.trim();
      }
      if (typeof event.commitSha === "string" && /^[0-9a-f]{7,40}$/i.test(event.commitSha)) {
        state.product.resultSha = event.commitSha;
      }
      if (typeof event.baselineSha === "string" && /^[0-9a-f]{7,40}$/i.test(event.baselineSha)) {
        state.product.baselineSha = event.baselineSha;
      }
      if (typeof event.inspectCommand === "string" && event.inspectCommand.trim()) {
        state.product.inspectCommand = event.inspectCommand.trim();
      } else if (state.product.baselineSha && state.product.resultSha) {
        state.product.inspectCommand =
          `git diff --no-ext-diff --no-textconv ${state.product.baselineSha} ${state.product.resultSha} --`;
      }
      if (typeof event.preservedArtifact === "string" && event.preservedArtifact.trim()) {
        state.product.preservedArtifact = event.preservedArtifact.trim();
      }
      if (Array.isArray(event.diffPreviewLines)) {
        state.product.diffPreviewLines = event.diffPreviewLines
          .filter((l) => typeof l === "string")
          .slice(0, 50);
        state.product.diffPreviewTruncated = event.diffPreviewTruncated === true;
        state.product.diffPreviewShownFiles =
          typeof event.diffPreviewShownFiles === "number"
            ? event.diffPreviewShownFiles
            : Math.min(5, files.length);
      }
      if (Array.isArray(event.timingMarks) && event.timingMarks.length > 0) {
        state.product.timingSummary = summarizeTimingMarks(event.timingMarks);
      } else if (event.timingSummary && typeof event.timingSummary === "object") {
        state.product.timingSummary = event.timingSummary;
      }
      if (typeof event.durationMs === "number" && event.durationMs >= 0) {
        state.product.durationMs = event.durationMs;
      }
      state.product.resultClassification = classification;
      if (event.advancesSession === true) {
        state.product.advancesSession = true;
      } else if (event.advancesSession === false) {
        state.product.advancesSession = false;
      }
      if (
        typeof event.engineeringHandoff === "string" &&
        event.engineeringHandoff.trim()
      ) {
        state.product.engineeringHandoff = event.engineeringHandoff
          .trim()
          .slice(0, 1_200);
      }
      const phase =
        classification === "VERIFIED"
          ? "Verified"
          : classification === "PARTIALLY_VERIFIED"
            ? "Partially verified"
            : classification === "FAILED"
              ? "Failed"
              : classification === "CANCELLED"
                ? "Cancelled"
                : "Not verified";
      setCard(
        state,
        "terminal",
        classification === "VERIFIED" ? "done" : "refused",
        `${classification} — ${files.length} file(s)`,
      );
      // Replace with authoritative changed-file set. Never clobber a non-empty
      // living set with an empty result when commit≠baseline (rematerialize
      // must not erase Cursor/Copilot file creates from /inspect).
      const priorFiles = Array.isArray(state.product.projectFiles)
        ? state.product.projectFiles.filter(
            (p) => typeof p === "string" && p.trim() && !p.startsWith("/"),
          )
        : [];
      const shaMoved =
        typeof state.product.resultSha === "string" &&
        typeof state.product.baselineSha === "string" &&
        state.product.resultSha.toLowerCase() !==
          state.product.baselineSha.toLowerCase();
      const nextFiles =
        files.length > 0
          ? files.slice().sort()
          : shaMoved && priorFiles.length > 0
            ? priorFiles.slice().sort()
            : files.slice().sort();
      state.product.projectFiles = nextFiles;
      state.product.projectEntries = nextFiles.map((path) => ({
        path,
        role: "modified",
      }));
      state.product.changedFileTotal = nextFiles.length;
      // Clear bridge/tool residue so the phase label owns the PATH column.
      state.product.currentDetail =
        nextFiles.length > 0
          ? `${nextFiles.length} file(s) changed`
          : "Engineering complete";
      if (!Array.isArray(state.product.sessionHistory)) {
        state.product.sessionHistory = [];
      }
      state.product.sessionHistory.push({
        preview: String(state.product.taskPreview || "task").slice(0, 60),
        classification,
      });
      if (state.product.sessionHistory.length > 8) {
        state.product.sessionHistory = state.product.sessionHistory.slice(-8);
      }
      setPathPhase(state, phase);
      // Completion must look idle — clear in-flight busy/heartbeat residue.
      state.heartbeat = null;
      state.product.busyLabel = null;
      state.product.busyDetail = null;
      state.product.busySince = null;
      state.product.awaitingInput = true;
      if (
        typeof state.product.taskStartedAt === "number" &&
        state.product.taskStartedAt > 0 &&
        typeof state.product.durationMs !== "number"
      ) {
        state.product.durationMs = Math.max(
          0,
          Date.now() - state.product.taskStartedAt,
        );
      }
      break;
    }
    case "session.environment.unavailable":
    case "session.infrastructure.failure": {
      const reason =
        typeof event.message === "string"
          ? event.message
          : typeof event.code === "string"
            ? event.code
            : "execution environment unavailable";
      state.product.infraFailure = reason;
      setPathPhase(state, "Infrastructure failure");
      setCloudFooter(state, "☁ Cleaning up…");
      break;
    }
    case "session.delivery.phase": {
      const phase =
        typeof event.phase === "string" && event.phase.trim()
          ? event.phase.trim()
          : "Preparing GitHub delivery";
      state.product.deliveryPhase = phase;
      setPathPhase(state, phase);
      break;
    }
    case "session.delivery.approval": {
      state.product.deliveryPhase = "Awaiting publication approval";
      state.product.deliveryApproval = {
        remote: typeof event.remote === "string" ? event.remote : "",
        baseBranch: typeof event.baseBranch === "string" ? event.baseBranch : "",
        taskBranch: typeof event.taskBranch === "string" ? event.taskBranch : "",
        status: typeof event.status === "string" ? event.status : "pending",
      };
      setPathPhase(state, "Awaiting publication approval");
      break;
    }
    case "session.delivery.result": {
      const status = typeof event.status === "string" ? event.status : "";
      state.product.deliveryResult = {
        status,
        remote: typeof event.remote === "string" ? event.remote : null,
        prNumber: typeof event.prNumber === "number" ? event.prNumber : null,
        prUrl: typeof event.prUrl === "string" ? event.prUrl : null,
        remoteBranchOk: event.remoteBranchOk === true,
        prOk: event.prOk === true,
        message: typeof event.message === "string" ? event.message : null,
      };
      if (status === "PUBLISHED") {
        state.product.deliveryPhase = "Pull request created";
        setPathPhase(state, "Pull request created");
      } else if (status === "DECLINED") {
        state.product.deliveryPhase = "Verified";
        state.product.deliveryApproval = null;
        setPathPhase(state, "Verified");
      } else if (status === "CANCELLED") {
        state.product.deliveryPhase = "Cancelled";
        setPathPhase(state, "Cancelled");
      } else if (status) {
        state.product.deliveryPhase = status;
        setPathPhase(state, status);
      }
      break;
    }
    default:
      break;
  }

  // While PATH independent validation is actively running, prefer Verifying.
  if (
    state.product.finalValidationStarted === true &&
    state.cards.validationRunning?.status === "active" &&
    state.product.pathPhase !== "Investigating failure" &&
    !state.cards.terminal?.arrived
  ) {
    setPathPhase(state, "Verifying");
  }
  // Cloud running footer while applying/validating after hydration.
  if (
    state.product.cloudSelected &&
    !state.product.disposed &&
    (state.cards.applying?.status === "active" ||
      state.cards.validationRunning?.status === "active")
  ) {
    const sec = state.heartbeat
      ? Math.floor(state.heartbeat.elapsedMs / 1000)
      : null;
    setCloudFooter(
      state,
      `☁ ${state.product.region || "europe-west4"} · Engineering Image · Running${
        sec != null ? ` · ${sec}s` : ""
      }`,
    );
  }

  // P1 decoration probe hook — MUST NOT ship enabled.
  if (opts.decorateGate2Accepted === true && !state.cards.gate2.arrived) {
    setCard(state, "gate2", "done", "accepted");
  }

  return state;
}

/**
 * Fold an ordered event list into Studio state.
 * @param {ReadonlyArray<Record<string, unknown>>} events
 * @param {{ sessionId?: string | null, decorateGate2Accepted?: boolean }} [opts]
 */
export function reduceStudioEvents(events, opts = {}) {
  let state = createEmptyStudioState();
  for (const event of events) {
    applyStudioEvent(state, event, opts);
  }
  return state;
}

/**
 * Text rendering of Studio cards. Elapsed-only liveness; no % / ETA / bar.
 * @param {ReturnType<typeof createEmptyStudioState>} state
 */
export function renderStudioText(state) {
  const lines = [];
  lines.push("PATH STUDIO — read-only live mirror");
  lines.push(
    state.sessionId
      ? `session: ${state.sessionId}`
      : "session: (waiting for first event)",
  );
  if (state.ignoredForeignCount > 0) {
    lines.push(`ignored foreign-session events: ${state.ignoredForeignCount}`);
  }
  lines.push("");
  for (const id of STUDIO_CARD_ORDER) {
    const card = state.cards[id];
    if (!card) continue;
    // Skip cards never reached stay "pending / not yet"
    const mark =
      card.status === "pending"
        ? "[ ]"
        : card.status === "skipped"
          ? "[~]"
          : card.status === "refused"
            ? "[x]"
            : card.status === "active"
              ? "[>]"
              : "[*]";
    lines.push(`${mark} ${card.title}: ${card.detail}`);
  }
  if (state.heartbeat) {
    const sec = Math.floor(state.heartbeat.elapsedMs / 1000);
    lines.push("");
    lines.push(`liveness: working on ${state.heartbeat.stage} — ${sec}s`);
  }
  if (state.sinkEnded) {
    lines.push("");
    lines.push("(sink ended — final state)");
  }
  return `${lines.join("\n")}\n`;
}

/**
 * Assert the rendered text contains no fabricated progress decoration.
 * @param {string} text
 */
export function assertNoFabricatedProgress(text) {
  if (/\d+\s*%/.test(text)) {
    throw new Error("fabricated percentage in Studio render");
  }
  if (/\bETA\b/i.test(text)) {
    throw new Error("fabricated ETA in Studio render");
  }
  if (/progress\s*bar|█|▓|filling/i.test(text)) {
    throw new Error("fabricated progress bar in Studio render");
  }
  return true;
}

/**
 * Stages reached in arrival order (for order-fidelity proofs).
 * @param {ReturnType<typeof createEmptyStudioState>} state
 */
export function arrivedCardSequence(state) {
  return STUDIO_CARD_ORDER.filter((id) => state.cards[id]?.arrived === true);
}
